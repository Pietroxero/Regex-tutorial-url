# REGEX Matching a URL

The purpose of this tutorial is explain using code snippets what a Regular Expression (Regex) will be functioning.

## Summary

Matching a URL: 
```
/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/
```

## Table of Contents

- [Anchors](#anchors)
- [Quantifiers](#quantifiers)
- [Character Classes](#character-classes)
- [Grouping and Capturing](#grouping-and-capturing)
- [Bracket Expressions](#bracket-expressions)

## Regex Components
A Regular Expression (also called regex) describing a pattern. It is used to locate or validate specific strings or patterns of text in a sentence, document, or any other character input. Regex uses both special and basic characters for the search. some of the basic components of a regex are character classes, anchors, quanitifiers, grouping. Character classes are used to include varying types of characters in your regex. Anchors specify the start or the end of a word/line. Grouping creates sections that can be used to allow quantities of the same section in a given row. 

### Anchors
Anchors are the start and finish for regex. They are between the forward slash at the start and enddof the expression. The beginning anchor ```^``` character and the end point ```&``` character for example. This charac ters have been highlighted below:

/```^```(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?```$```/

^ signifies that a string will begin with the character grouping that follows it. It would return strings that contain H T T P and optional S (lowercase as Regex is case sensitive) followed by slash, slash.

The $ anchor is signifying that a string ends with the characters that come before it. Within the example above the string

### Quantifiers

A Quantifier sets the limits of the string the regex matches. Within  a set of {min, max} you would include the minimum, and the maximum numbers of the characters that the regex searchs for. However quantifiers match as many occurances for particular pattarns as possible. In the example below, {} curly brackets can provide 3 ways to set limits for a possible match:
  { n } - this would match the pattern exactly N number of times with in a regex
  { N, } - would match the pattern at least N number of times.
  { N, X } - matches the pattern from a minimum range N number of times to the maximum range N number of times.

For the expression we touch on in this tutorial, the first quantifier that we see is ```?```, /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/ this character is going to match 0 - 1, meaning that it wll match even if the item is omitted. This quantifier comes after ```s``` which means that  our URL can start with optionally ```http```, ```https```, however something like ```httpf``` will not be part of that match.

the second quantifier here is the second ```?``` but it is then followed by a group of characters with a set of parenthasis.

/^(https?:\/\/)```?```([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/
with its different placement in our regex, the quantifier has a different role as it will validatge the entire group present in our parenthesis. It is going to match weather ```https://``` or even ```https://``` if they are found or missing
Example:

```
https://www.stackoverflow.com
www.stackoverflow.com
```

Third quanitifier is ```+``` meaning it will match one or more times. Meaning that the item that is before it has to happen once but can also happen for an infinite amount of time. The item before our quantifier: ```[\da-z\.]``` means the match will work for any string that is between the ```https://``` and the last dot before ```com```, ```org```.

/^(https?:\/\/)?([\da-z\.-]```+```)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/

Fourth quantifier is a curly bracket: ```{2,6}``` in our expression will match the amount of times specified within the brackets. The comma signifies it is going to match a specific amount of times between the numbers in the bracket. in this case it is going to match between 2 and 6.

/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]```{2,6}```)([\/\w \.-]*)*\/?$/

Preceeding this ```[a-z\.]``` is seen and will match our domain to be within 2-5 characters that are lower case and have a dot in them. Example:
```
.com
.co
.gov
.org
.edu
```
Finally, the ```*``` quantifier shows twice in our regex:
/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]```*```)```*```\/?$/

 the ```*``` quantifier before ```[\/\w \.-]``` will match a length of a string after the ```.com```, ```.edu```, and so on. Example:
 
 ```
www.youtube.com/peteyxero5
```

The second ```*``` found in the expression found before ```([\/\w \.-]*)```, and found before the parenthesis means it will be matching the URL with varying levels seperated by ```/``` after the root.


### Character Classes

Character Classes are uysed to search for types of characters instead of specific ones. In our regex for URLs, the " \d " is refering to digits anywhere from 0 to 9. 

In order to search for characters in a given range such as, a-z (lower case as regex is case sensitive), 0 - 9. a-z in the URL regex is a range character class. You are able to be specific with character ranges by changing the values at the start and at the end of the regex. 

In the Regex used for this tutorial there arer3 sets of differente character classes that are used.

1. ```\w``` matches any alphanumeric character including the underscore: ```a-z```, ```A-Z```, ```0-9```, and ```_```.
2. ```a-z``` matches with any lowercase alphabetic character
3. ```\d``` matches with any number character ```0-9```


### Grouping and Capturing
Groupings are going to be seperated by parenthesis. Below you will find broken down pieces of our regex to better explaing groupings.

```(https?:\/\/)```
In this group it will match if the regex finds the following:
String ```http``` and colon ```:```
optionally an ```s``` that could or could not be present in the URL
and two forward slahes ```//``` found in the expression as ```\/\/```

```([\da-z\.-]+)```
In this portion of the expression it will match if the string has at least one of the characters in the expression thanks to the quantifier used ```+```

```([a-z\.]{2,6}```
a bracket quantifier here in the grouping means it will match off if the number of characters match our quantifier (2 through 6) and if the characters are lowercase.

```([\/\w \.-]*)```
In this grouping it will match and empty string or a string where the cahracters are the as shown in the brackets.

### Bracket Expressions
Bracket Expressions show a range of charactes that have to be matched.

-```[\da-z\.-]```
    ```\d``` = any numeric character
    ```a-z``` = any lowercase letter
    ```\.``` = a dot is neccessary
    ```-```  = a hyphen is needed

- ```[a-z\.]```
    ```a-z``` = any lowercase letter
   ```\.``` = a dot is neccessary

- ```[\/\w \.-]```
     ```\/``` = forward slash is needed
     ```\w``` = alphanumeric character
     ```" "``` = space
     ```\.``` = dot
     ```-``` = hyphen

## Author
👩🏼‍💻 Peter is a student taking a Full Stack webdevelopment bootcamp course. You can reach out via eamil at peterdelsol@gmail.com or view their github https://github.com/Pietroxero
